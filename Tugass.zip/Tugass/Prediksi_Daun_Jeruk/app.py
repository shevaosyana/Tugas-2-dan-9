from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_predictions', methods=['POST'])
def generate_predictions():
    num_predictions = int(request.form['numPredictions'])
    predictions = []
    cumulative_probability = 0

    for i in range(1, num_predictions + 1):
        random_prediction = round(random.uniform(9, 15), 2)
        probability = 1 / num_predictions
        cumulative_probability += probability
        interval = f"{round(random_prediction - 0.5, 2)} - {round(random_prediction + 0.5, 2)} cm"
        random_value = round(random.random(), 4)

        predictions.append({
            'i': i,
            'randomPrediction': random_prediction,
            'probability': probability,
            'cumulativeProbability': cumulative_probability,
            'interval': interval,
            'randomValue': random_value
        })

    return jsonify(predictions)

if __name__ == '__main__':
    app.run(debug=True)
